﻿using MauiAppTempoAgoraSQLite.Models;
using MauiAppTempoAgoraSQlite;
using MauiAppTempoAgoraSQlite.Models;

namespace MauiAppTempoAgoraSQLite.Helpers
{
    public class SQLiteDatabaseHelper
    {
        readonly SQLiteAsyncConnection _conn;

        public SQLiteDatabaseHelper(string path)
        {
            _conn = new SQLiteAsyncConnection(path);
            object value = _conn.CreateTableAsync<Tempo>().Wait();
        }

        public Task<int> Insert(Tempo p)
        {
            return _conn.InsertAsync(p);
        }

        public Task<int> Delete(int id)
        {
            return _conn.Table<Tempo>().DeleteAsync(i => i.Id == id);
        }

        public Task<List<Tempo>> GetAll()
        {
            return _conn.Table<Tempo>().OrderByDescending(i => i.Id).ToListAsync();
        }

        public Task<List<Tempo>> Search(string q)
        {
            string sql = "SELECT * FROM Tempo " +
                         "WHERE Cidade LIKE '%" + q + "%'";

            return _conn.QueryAsync<Tempo>(sql);
        }
    } // Fecha classe SQLiteDatabaseHelper

    internal class SQLiteAsyncConnection
    {
        private string path;

        public SQLiteAsyncConnection(string path)
        {
            this.path = path;
        }

        internal object CreateTableAsync<T>()
        {
            throw new NotImplementedException();
        }

        internal async Task<int> InsertAsync(Tempo p)
        {
            throw new NotImplementedException();
        }

        internal Task<List<T>> QueryAsync<T>(string sql)
        {
            throw new NotImplementedException();
        }

        internal object Table<T>()
        {
            throw new NotImplementedException();
        }
    }
}